module Game2048ByFrancisAdams {
	requires java.desktop;
	requires org.junit.jupiter.api;
}